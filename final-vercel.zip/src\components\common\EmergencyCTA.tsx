import Link from "next/link";

type EmergencyCTAProps = {
  compact?: boolean;
};

export default function EmergencyCTA({ compact }: EmergencyCTAProps) {
  return null;
}

