"use client";

import Link from "next/link";
import { useState } from "react";
import {
  useCookieConsent,
  type CookieConsent,
} from "@/hooks/useCookieConsent";
import CookieSettingsModal from "@/components/CookieSettingsModal";

const DEFAULT_CONSENT: CookieConsent = {
  necessary: true,
  statistics: false,
  marketing: false,
};

export default function CookieBanner() {
  const {
    consent,
    isReady,
    hasConsent,
    acceptAll,
    acceptNecessaryOnly,
    updateConsent,
  } = useCookieConsent();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  if (!isReady) {
    // Avoid layout shift / hydration mismatch until localStorage has been checked
    return null;
  }

  const effectiveConsent = consent ?? DEFAULT_CONSENT;

  const handleSaveSettings = (next: CookieConsent) => {
    updateConsent(next);
    setIsSettingsOpen(false);
  };

  const handleOpenSettings = () => {
    setIsSettingsOpen(true);
  };

  const handleCloseSettings = () => {
    setIsSettingsOpen(false);
  };

  return (
    <>
      <CookieSettingsModal
        isOpen={isSettingsOpen}
        initialConsent={effectiveConsent}
        onSave={handleSaveSettings}
        onCancel={handleCloseSettings}
      />

      {!hasConsent && (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 shadow-[0_-4px_20px_rgba(15,23,42,0.15)] backdrop-blur">
          <div className="mx-auto flex max-w-5xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:py-3">
            <div className="space-y-1">
              <p className="text-sm font-semibold text-slate-900">
                Wir verwenden Cookies
              </p>
              <p className="text-xs text-slate-600 sm:text-sm">
                Wir nutzen Cookies, um unsere Website für
                Haushaltsgeräte-Reparaturen technisch bereitzustellen und
                optional zur Reichweitenmessung und für Marketing. Sie können
                selbst entscheiden, welche Cookies wir setzen. Details finden
                Sie in unserer{" "}
                <Link
                  href="/datenschutz"
                  className="font-medium text-brand underline underline-offset-2 hover:text-brand/90"
                >
                  Datenschutzerklärung
                </Link>
                .
              </p>
            </div>

            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-end">
              <button
                type="button"
                onClick={acceptNecessaryOnly}
                className="inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-700 shadow-sm transition hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand sm:text-sm"
              >
                Nur notwendige Cookies
              </button>
              <button
                type="button"
                onClick={handleOpenSettings}
                className="inline-flex items-center justify-center rounded-full border border-slate-200 bg-slate-900 px-4 py-2 text-xs font-medium text-white shadow-sm transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand sm:text-sm"
              >
                Einstellungen
              </button>
              <button
                type="button"
                onClick={acceptAll}
                className="inline-flex items-center justify-center rounded-full bg-brand px-4 py-2 text-xs font-medium text-white shadow-sm transition hover:bg-brand/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand sm:text-sm"
              >
                Alle akzeptieren
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

